<html>

<head>
<title>Section Change</title>
</head>
<body>
<form action="" method="post">
<hr>
Enter Student ID : <input type="text" name="studid" />
<input type="submit" name="search" value="Search the Student"/>
<hr>
</form>


<?php  // creating a database connection 
$row[0]="";
$row[1]="";
$row[2]="";
$studid="";
if(isset($_POST["search"]))
{
$studid = $_POST["studid"];
   
   $con = mysqli_connect("localhost","root","","hamaray_bachchay"); 
   if($con) 
      { echo "Connection Successful."; } 
   else 
      { die('Could not connect '); } 
  
     	 
	echo "<hr>";
	$q2 = "select sec.section_C,sec.name,sec.classid from student stu,section sec where stu.section=sec.name and studid=$studid";
	$query_id2 = mysqli_query($con, $q2); 		
	 
	$row = mysqli_fetch_row($query_id2);
}

?>
<form action="" method="post">
<hr>
Date must be in the format "DD/MM/YYYY"<br>
<TABLE BORDER=0>
  <col width="150">
  <col width="320">

<TR><TD >Enter Date</TD><TD><input type="text" name="C_Date" /></TD></TR>
</TABLE>
<hr>
<TABLE BORDER=0>
<TR><TD >Student ID:</TD><TD> <input type="text" name="stud" value="<?php echo $studid;?>" readonly/></TD></TR>
<TR><TD >Current Class: </TD><TD><input type="text" name="c_class" value="<?php echo $row[2];?>" readonly/></TD></TR>
<TR><TD >Current Section: </TD><TD><input type="text" name="c_sec" value="<?php echo $row[0];?>" readonly/></TD></TR>
<TR><TD >Current Section Name: </TD><TD><input type="text" name="c_name" value="<?php echo $row[1];?>" readonly/></TD></TR>



<TR><TD >New Section: </TD><TD><select name="n_sec" required>
			  <option value="A">A</option>
				<option value="B">B</option>
						
			  </select></TD></TR>


<TR><TD >Reason:</TD><TD> <input type="text" name="reason"/></TD></TR>


<TR><TD ><input type="submit" name="change" value="Change Section"/></TD></TR>
</TABLE>
</form>

</body>
</html>

<?php  // creating a database connection
if(isset($_POST["change"]))
{
echo "<hr>";
   
   $con = mysqli_connect("localhost","root","","hamaray_bachchay"); 
   if($con) 
      { echo "Connection Successful."; } 
   else 
      { die('Could not connect'); } 
 echo "<hr>"; 

$stud=$_POST['stud'];
$c_sec=$_POST['c_sec'];
$c_name=$_POST['c_name'];
$c_class=$_POST['c_class'];
$n_sec=$_POST['n_sec'];
$Reason=$_POST['reason'];
$C_Date=$_POST['C_Date'];


if($c_sec!=$n_sec)
{
	echo "yes";
	$q1="SELECT * FROM sec_History WHERE studid='".$stud."'ORDER BY changee";
	$q_id=mysqli_query($con,$q1);
	
	$nrows = mysqli_num_rows($q_id);
	
	$serial=0;
	if($nrows==0){
		$serial=0;
	}
	else{
	$serial=$res[$nrows-1]['changee']+1;
	}
	$q1="insert into sec_History(studID,changee,reason,prev_section,CH_Date) values('".$stud."','".$serial."','".$Reason."','".$c_name."',STR_TO_DATE('$C_Date', '%d/%m/%Y'))";
	$q_id2=mysqli_query($con,$q1);
	

	$q3 = "select name from section where name!='".$c_name."' and classid='".$c_class."'";
	$query_id3 = mysqli_query($con, $q3); 		
	 
	$row3 = mysqli_fetch_row($query_id3);


	 $q="update student set section='$row3[0]' where studid = $stud";
	 $query_id = mysqli_query($con, $q); 		
	  

}

if($c_sec==$n_sec)
{
	echo "You are already in this section";
}

	 
	
}

?>
