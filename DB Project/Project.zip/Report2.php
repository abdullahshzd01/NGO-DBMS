<?php
    // Create connection
    $mysql = new mysqli("localhost", "root", "", "hamaray_bachchay");

    // Check connection
    if ($mysql->connect_error)
    {
        echo "Failed to connect to MySQL: " . $mysql -> connect_error;
        exit();
    }

    $SEC = $_POST["sec"];

    $query1 = "SELECT section, count(*)'NoOfStudents' 
    FROM student
    AND section = $SEC;";

    $query2 = "SELECT section, count(*)'Males' 
    FROM student 
    WHERE gender='M'
    AND section = $SEC;";

    $query3 = "SELECT section, count(*)'Females'
    FROM student 
    WHERE gender='F'
    AND section = $SEC;";
    
    $result1 = $mysql->query($query1);
    $result2 = $mysql->query($query2);
    $result3 = $mysql->query($query3);

    if ($result1->num_rows > 0 || $result2->num_rows > 0 || $result3->num_rows > 0)
    {
        // output data of each row
        echo "<table border=2 align=center><tr><th>Section</th><th>NoOfStudents</th><th>Males</th><th>Females</th></tr>";

        // while($row1 = $result1->fetch_assoc() && $row2 = $result2->fetch_assoc() && $row3 = $result3->fetch_assoc())
        // {
        //     echo "<tr><td>" . $row1["section"]. "</td><td>" . $row1["NoOfStudents"]. "</td><td>" . $row2["Males"]. "</td><td>" . $row3["Females"]. "</td></tr>";
        // }

        while ($row1 = $result1->fetch_assoc())
        {
            while ($row2 = $result2->fetch_assoc())
            {
                while ($row3 = $result3->fetch_assoc())
                {
                    echo "<tr><td>" . $row1["section"]. "</td><td>" . $row1["NoOfStudents"]. "</td><td>" . $row2["Males"]. "</td><td>" . $row3["Females"]. "</td></tr>";
                }
            }
        }
        echo "</table>";
    }
    else
        echo "No results";

    echo "<br><br>";        

    $mysql->close();
?>