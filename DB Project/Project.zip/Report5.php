<?php
    // Create connection
    $mysql = new mysqli("localhost", "root", "", "hamaray_bachchay");

    // Check connection
    if ($mysql->connect_error)
    {
        echo "Failed to connect to MySQL: " . $mysql -> connect_error;
        exit();
    }
    
    $CNIC = $_POST["cnic"];

    $query = "SELECT s.studID ID, s.name Name, s.section Section, g.name Guardian, g.cnic GCNIC 
    FROM student s, guardian g
    where (s.m_cnic = $CNIC or s.f_cnic = $CNIC) AND s.g_cnic = g.cnic;";

    $result = $mysql->query($query);

    if ($result->num_rows > 0)
    {
        // output data of each row
        echo "<table border=2 align=center><tr><th>ID</th><th>Name</th><th>Section</th><th>Guardian</th><th>Guardian Cnic</th></tr>";

        while($row = $result->fetch_assoc())
        {
            echo "<tr><td>" . $row["ID"] . "</td><td>" . $row["Name"]. "</td><td>" . $row["Section"]. "</td><td>" . $row["Guardian"]. "</td><td>" . $row["GCNIC"]. "</td></tr>";
        }
        echo "</table>";
    }
    else
        echo "No results";

    echo "<br><br>";

    

    $mysql->close();
?>