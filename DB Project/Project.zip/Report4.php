<?php
    // Create connection
    $mysql = new mysqli("localhost", "root", "", "hamaray_bachchay");

    // Check connection
    if ($mysql->connect_error)
    {
        echo "Failed to connect to MySQL: " . $mysql -> connect_error;
        exit();
    }

    // echo "Student ID: <input type="number" name="id" placeholder="Enter Name Here">";
    
    $StID = $_POST["id"];

    // echo "Student id entered is " $StID;

    // $query = "SELECT s.Name, f.name 'Father',m.name 'Mother',g.name'Gaurdian'
    // FROM student s, parent f, parent m, guardian g
    // WHERE s.StudID = " . $StID . "
    // AND s.F_CNIC = f.cnic
    // AND s.M_CNIC = m.cnic
    // AND s.G_CNIC = g.cnic;";

    $query = "SELECT s.Name, f.name 'Father',m.name 'Mother',g.name'Gaurdian'
    FROM student s, parent f, parent m, guardian g
    WHERE s.StudID = $StID
    AND s.F_CNIC = f.cnic
    AND s.M_CNIC = m.cnic
    AND s.G_CNIC = g.cnic;";

    $result = $mysql->query($query);

    if ($result->num_rows > 0)
    {
        // output data of each row
        echo "<table border=2 align=center><tr><th>Name</th><th>Father</th><th>Mother</th><th>Guardian</th></tr>";

        while($row = $result->fetch_assoc())
        {
            echo "<tr><td>" . $row["Name"] . "</td><td>" . $row["Father"]. "</td><td>" . $row["Mother"]. "</td><td>" . $row["Gaurdian"]. "</td></tr>";
        }
        echo "</table>";
    }
    else
        echo "No results";

    echo "<br><br>";

    

    $mysql->close();
?>